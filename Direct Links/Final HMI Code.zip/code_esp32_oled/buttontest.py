import my_oled
import time

while True:
    print("Button Value:", my_oled.buttonSELECT.value())  # Should print 0 when not pressed, 1 when pressed
    time.sleep(0.1)