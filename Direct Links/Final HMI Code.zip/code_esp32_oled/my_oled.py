from machine import Pin, SoftI2C
from machine import UART
import ssd1306
import gfx
from time import sleep

i2c = SoftI2C(scl=Pin(21), sda=Pin(47))

# Defines Buttons #
buttonUP = Pin(4, Pin.IN, Pin.PULL_UP)
buttonDOWN = Pin(5, Pin.IN, Pin.PULL_UP)
buttonSELECT = Pin(6, Pin.IN, Pin.PULL_UP)

oled_width = 128
oled_height = 64
oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)
graphics = gfx.GFX(oled_width, oled_height, oled.pixel)


def print_text(msg,x=0,y=0, color=1):
    print('I am printing text')

    # clear the screen

    #place text on the screen
    oled.text(msg, x,y, color)
    # show the screen
    


def plot_line(*args,**kwargs):
    print('I am plotting a line')
